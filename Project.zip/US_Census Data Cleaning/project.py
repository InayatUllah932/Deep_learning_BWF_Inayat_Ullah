import matplotlib.pyplot as plt
import pandas as pd
import glob
census_files = glob.glob("*.csv")
dfs = []

# Loop through each file and load it into a DataFrame
for file in census_files:
    df = pd.read_csv(file)
    dfs.append(df)

# Concatenate all the DataFrames together into one DataFrame
us_census = pd.concat(dfs, ignore_index=True)

# Here I show the head of dataFram
print(us_census.head()) 

# To print the data type 
print(us_census.dtypes)

# Here I convert the data to correct form
us_census['Income']=pd.to_numeric(us_census['Income'].replace('\$','',regex=True))
us_census['Pacific']=pd.to_numeric(us_census['Pacific'].str.replace('%',''))
us_census['Asian']=pd.to_numeric(us_census['Asian'].str.replace('%',''))
us_census['Hispanic']=pd.to_numeric(us_census['Hispanic'].str.replace('%',''))
us_census['White']=pd.to_numeric(us_census['White'].str.replace('%',''))
us_census['Black']=pd.to_numeric(us_census['Black'].str.replace('%',''))
us_census['Native']=pd.to_numeric(us_census['Native'].str.replace('%',''))

print(us_census.dtypes)

print(us_census.head())

# Split GenderPop column into Men and Women columns
us_census[['Men', 'Women']] = us_census['GenderPop'].str.split("_",expand=True)

# Remove "M" and "F" characters from Men and Women columns
us_census['Men'] = us_census['Men'].str.replace('M', '')
us_census['Women'] = us_census['Women'].str.replace('F', '')

# Convert Men and Women columns to numeric data types
us_census['Men'] = pd.to_numeric(us_census['Men'])
us_census['Women'] = pd.to_numeric(us_census['Women'])

print(us_census.head())

print(us_census['Women'].isna().sum())

estimated_women_pop = us_census['TotalPop'] - us_census['Men']
us_census['Women'] = us_census['Women'].fillna(value=estimated_women_pop)

# Now if I check the number of null value in the dataFram. The below code will show zero null value
print(us_census['Women'].isna().sum())

us_census.drop_duplicates()

women_column = us_census['Women']
Income_column = us_census['Income']
plt.scatter(women_column, Income_column)
plt.xlabel("Women")
plt.ylabel("Imcome")
plt.title("Scatter of Women_Imcome")
plt.show()

plt.hist(us_census["Hispanic"], bins=20)
plt.xlabel("Percentage of Hispanic Population")
plt.ylabel("Frequency")
plt.title("Histogram of Hispanic Population")
plt.show()

plt.hist(us_census["Asian"], bins=20)
plt.xlabel("Percentage of Asian Population")
plt.ylabel("Frequency")
plt.title("Histogram of Asian Population")
plt.show()

plt.hist(us_census["White"], bins=20)
plt.xlabel("Number of White")
plt.ylabel("Frequency")
plt.title("Histogram of white column")
plt.show()

plt.hist(us_census["Black"], bins=20)
plt.xlabel("Number of Black")
plt.ylabel("Frequency")
plt.title("Histogram of Black column")
plt.show()

plt.hist(us_census["Native"], bins=20)
plt.xlabel("Native")
plt.ylabel("Frequency")
plt.title("Histogram of Native column")
plt.show()





